-- 1. Database Creation
CREATE DATABASE IF NOT EXISTS college_bus_system;
USE college_bus_system;

-- 2. Clean Existing Tables (To prevent old schema conflicts)
DROP TABLE IF EXISTS attendance;
DROP TABLE IF EXISTS fee_payments;
DROP TABLE IF EXISTS students;

-- 3. Students Table (With User Password Support)
CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    register_number VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    dob DATE NOT NULL,
    dept VARCHAR(50) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    profile_pic LONGTEXT,
    route_allocated VARCHAR(50) NOT NULL,
    boarding_address VARCHAR(255) NOT NULL,
    allocated_fee DECIMAL(10, 2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 4. Fee Payments Table
CREATE TABLE fee_payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    transaction_id VARCHAR(100) NOT NULL UNIQUE,
    register_number VARCHAR(50) NOT NULL,
    name VARCHAR(100) NOT NULL,
    dept VARCHAR(50) NOT NULL,
    route_number VARCHAR(50) NOT NULL,
    distance_km INT NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    payment_status VARCHAR(20) DEFAULT 'CREDITED',
    payment_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (register_number) REFERENCES students(register_number) ON DELETE CASCADE
);

-- 5. Attendance Table
CREATE TABLE attendance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    register_number VARCHAR(50) NOT NULL,
    route_number VARCHAR(50) NOT NULL,
    attendance_date DATE NOT NULL,
    status ENUM('PRESENT', 'ABSENT') NOT NULL,
    marked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (register_number) REFERENCES students(register_number) ON DELETE CASCADE
);

-- 6. Authentication Fix for Root & Admin
CREATE USER IF NOT EXISTS 'college_admin'@'localhost' IDENTIFIED BY 'admin123';
GRANT ALL PRIVILEGES ON college_bus_system.* TO 'college_admin'@'localhost';
ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '1312';
FLUSH PRIVILEGES;