const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const path = require('path');
const { createHash, randomBytes, scrypt, timingSafeEqual } = require('crypto');
const { promisify } = require('util');

const app = express();
app.use(express.json({ limit: '15mb' }));
app.use(cors());
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'Bus Management System.html'));
});
const scryptAsync = promisify(scrypt);

async function hashPassword(password) {
  const salt = randomBytes(16).toString('hex');
  const derivedKey = await scryptAsync(password, salt, 64);
  return `${salt}:${derivedKey.toString('hex')}`;
}

async function verifyPassword(password, storedValue) {
  const [salt, storedKeyHex] = String(storedValue || '').split(':');
  if (salt && /^[a-f0-9]{128}$/i.test(storedKeyHex || '')) {
    const storedKey = Buffer.from(storedKeyHex, 'hex');
    const derivedKey = await scryptAsync(password, salt, storedKey.length);
    return timingSafeEqual(storedKey, derivedKey);
  }

  const providedBytes = Buffer.from(password);
  const storedBytes = Buffer.from(String(storedValue || ''));
  return providedBytes.length === storedBytes.length && timingSafeEqual(providedBytes, storedBytes);
}

// Exact database connection configuration
const dbConfig = {
  host: '127.0.0.1',
  port: 3306,
  user: 'root',
  password: '1312',
  database: 'college_bus_system',
  authPlugins: {
    sha256_password: mysql.authPlugins?.sha256_password,
    caching_sha2_password: mysql.authPlugins?.caching_sha2_password
  }
};
const db = mysql.createConnection(dbConfig);
const attendancePool = mysql.createPool(dbConfig);

db.connect((err) => {
  if (err) {
    console.error('❌ Database connection failed:', err.message);
  } else {
    console.log('✅ Connected to MySQL Database (college_bus_system) successfully!');
  }
});

// Log in an existing student, or create an account the first time a register number is used.
app.post('/api/login', (req, res) => {
  const {
    name, register_number, password, dob, dept, phone, profile_pic,
    route_allocated, boarding_address, allocated_fee
  } = req.body;
  const userPassword = typeof password === 'string' ? password : '';
  const normalizedRegisterNumber = typeof register_number === 'string' ? register_number.trim() : '';

  if (!normalizedRegisterNumber || userPassword.length < 8 || userPassword.length > 128) {
    return res.status(400).json({ success: false, error: 'A register number and a password of 8 to 128 characters are required.' });
  }

  const checkSql = 'SELECT * FROM students WHERE register_number = ? LIMIT 1';
  db.query(checkSql, [normalizedRegisterNumber], async (err, rows) => {
    if (err) return res.status(500).json({ success: false, error: err.message });
    if (!rows || rows.length === 0) {
      const requiredDetails = [name, dob, dept, phone, route_allocated, boarding_address];
      const fee = Number(allocated_fee);
      if (requiredDetails.some(value => typeof value !== 'string' || !value.trim()) || !Number.isFinite(fee) || fee <= 0) {
        return res.status(400).json({
          success: false,
          error: 'New register number detected. Complete your name, date of birth, department, phone, and route details to create your account.'
        });
      }

      try {
        const passwordHash = await hashPassword(userPassword);
        const insertSql = `
          INSERT INTO students (name, register_number, password, dob, dept, phone, profile_pic, route_allocated, boarding_address, allocated_fee)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `;
        db.query(insertSql, [
          name.trim(), normalizedRegisterNumber, passwordHash, dob, dept, phone.trim(),
          profile_pic || null, route_allocated, boarding_address, fee
        ], (insertError, result) => {
          if (insertError) {
            if (insertError.code === 'ER_DUP_ENTRY') {
              return res.status(409).json({ success: false, error: 'This register number was just created. Please log in again.' });
            }
            return res.status(500).json({ success: false, error: insertError.message });
          }

          return res.status(201).json({
            success: true,
            message: 'Account created and login successful.',
            student: {
              id: result.insertId,
              name: name.trim(),
              register_number: normalizedRegisterNumber,
              dob,
              dept,
              phone: phone.trim(),
              profile_pic: profile_pic || null,
              route_allocated,
              boarding_address,
              allocated_fee: fee
            }
          });
        });
      } catch (createError) {
        console.error('Student account creation failed:', createError);
        return res.status(500).json({ success: false, error: 'Student account could not be created.' });
      }
      return;
    }

    const existing = rows[0];
    try {
      const storedPassword = String(existing.password || '');
      const isPasswordHash = /^[a-f0-9]{32}:[a-f0-9]{128}$/i.test(storedPassword);
      if (!await verifyPassword(userPassword, storedPassword)) {
        return res.status(401).json({
          success: false,
          message: 'This student ID already has an account, but the password does not match. Check the password and try again.'
        });
      }
      if (!isPasswordHash) {
        const passwordHash = await hashPassword(userPassword);
        await db.promise().query(
          'UPDATE students SET password = ? WHERE register_number = ?',
          [passwordHash, normalizedRegisterNumber]
        );
      }
    } catch (verifyError) {
      console.error('Student password verification failed:', verifyError);
      return res.status(500).json({ success: false, error: 'Student login could not be completed.' });
    }

    const student = { ...existing };
    delete student.password;
    return res.json({ success: true, message: 'Login successful!', student });
  });
});

// Profile Photo Sync API
app.post('/api/update-photo', (req, res) => {
  const { register_number, profile_pic } = req.body;
  const sql = 'UPDATE students SET profile_pic = ? WHERE register_number = ?';
  db.query(sql, [profile_pic, register_number], (err) => {
    if (err) return res.status(500).json({ success: false, error: err.message });
    res.json({ success: true });
  });
});

function getIndiaDate() {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Kolkata',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).formatToParts(new Date());
  const dateParts = Object.fromEntries(parts.map(part => [part.type, part.value]));
  return `${dateParts.year}-${dateParts.month}-${dateParts.day}`;
}

app.get('/api/attendance/today/:register_number', async (req, res) => {
  const registerNumber = String(req.params.register_number || '').trim().toUpperCase();
  if (!registerNumber) {
    return res.status(400).json({ success: false, error: 'Register number is required.' });
  }

  try {
    const [rows] = await db.promise().query(
      `SELECT status, route_number, DATE_FORMAT(attendance_date, '%Y-%m-%d') AS attendance_date, marked_at
       FROM attendance
       WHERE register_number = ? AND attendance_date = ?
       ORDER BY marked_at DESC
       LIMIT 1`,
      [registerNumber, getIndiaDate()]
    );
    return res.json({ success: true, attendance: rows[0] || null });
  } catch (err) {
    console.error('Could not load today attendance:', err);
    return res.status(500).json({ success: false, error: 'Could not load today attendance.' });
  }
});

// 3. Fee Payment API
app.post('/api/pay-fee', (req, res) => {
  const { register_number, name, dept, route_number, distance_km, amount } = req.body;
  const checkSql = 'SELECT transaction_id FROM fee_payments WHERE register_number = ? LIMIT 1';
  db.query(checkSql, [register_number], (checkErr, rows) => {
    if (checkErr) return res.status(500).json({ success: false, error: checkErr.message });
    if (rows && rows.length > 0) {
      return res.status(400).json({
        success: false,
        already_paid: true,
        transaction_id: rows[0].transaction_id,
        message: 'Fee payment already completed for this student!'
      });
    }
    const txnId = 'TXN-' + Math.floor(100000 + Math.random() * 900000);
    const sql = `
      INSERT INTO fee_payments (transaction_id, register_number, name, dept, route_number, distance_km, amount, payment_status)
      VALUES (?, ?, ?, ?, ?, ?, ?, 'CREDITED')
    `;
    db.query(sql, [txnId, register_number, name, dept, route_number, distance_km, amount], (err) => {
      if (err) return res.status(500).json({ success: false, error: err.message });
      res.json({ success: true, transaction_id: txnId });
    });
  });
});

// 4. One attendance mark per student per India calendar day.
app.post('/api/attendance', async (req, res) => {
  const registerNumber = String(req.body?.register_number || '').trim().toUpperCase();
  const routeNumber = req.body?.route_number;
  const status = req.body?.status;
  if (!registerNumber || !routeNumber || !['PRESENT', 'ABSENT'].includes(status)) {
    return res.status(400).json({ success: false, error: 'Register number, route, and a valid attendance status are required.' });
  }

  const lockName = `attendance:${createHash('sha256').update(registerNumber).digest('hex').slice(0, 48)}`;
  let connection;
  let hasLock = false;
  let destroyConnection = false;
  try {
    connection = await attendancePool.promise().getConnection();
    const [lockRows] = await connection.query('SELECT GET_LOCK(?, 5) AS acquired', [lockName]);
    hasLock = lockRows[0]?.acquired === 1;
    if (!hasLock) {
      return res.status(503).json({ success: false, error: 'Attendance is busy. Please try again.' });
    }

    const attendanceDate = getIndiaDate();
    const [existingRows] = await connection.query(
      'SELECT status FROM attendance WHERE register_number = ? AND attendance_date = ? LIMIT 1',
      [registerNumber, attendanceDate]
    );
    if (existingRows.length > 0) {
      return res.status(409).json({
        success: false,
        already_marked: true,
        status: existingRows[0].status,
        error: `Attendance already marked ${existingRows[0].status.toLowerCase()} for today (IST).`
      });
    }

    await connection.query(
      'INSERT INTO attendance (register_number, route_number, attendance_date, status) VALUES (?, ?, ?, ?)',
      [registerNumber, routeNumber, attendanceDate, status]
    );
    return res.json({ success: true, status, attendance_date: attendanceDate, marked_at: new Date().toISOString() });
  } catch (err) {
    console.error('Could not record attendance:', err);
    return res.status(500).json({ success: false, error: 'Could not record attendance in the database.' });
  } finally {
    if (connection && hasLock) {
      try {
        await connection.query('SELECT RELEASE_LOCK(?)', [lockName]);
      } catch (err) {
        console.error('Could not release attendance lock:', err);
        destroyConnection = true;
      }
    }
    if (connection) {
      if (destroyConnection) connection.destroy();
      else connection.release();
    }
  }
});

const PORT = Number(process.env.PORT) || 5000;
app.listen(PORT, () => {
  console.log(`🚀 Transit app running on http://localhost:${PORT}`);
});